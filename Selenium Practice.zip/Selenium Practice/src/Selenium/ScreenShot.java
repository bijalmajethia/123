package Selenium;

import org.testng.annotations.Test;
import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.TakesScreenshot;


public class ScreenShot {
	@Test
	public void takescreenshot() throws Exception
	{
		WebDriver driver;
		driver = new FirefoxDriver();
		driver.get("https://www.opencart.com/");
		this.takeSnapShot(driver,"D://screenshot.png");
	}
	public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{
		//Convert web driver object to TakeScreenshot
		TakesScreenshot scrShot=((TakesScreenshot)webdriver);
		//call getScreenshotAs method to create image file
		File ScrFile = scrShot.getScreenshotAs(OutputType.FILE);
		//Move image file to new destination
		File DestFile = new File(fileWithPath);
		//copy file at destination
		FileUtils.copyFile(ScrFile,DestFile);
	}
}