package Selenium;

import org.junit.*;

public class JunitDemo2 {
	@Test
	public void a1b1()
	{
		System.out.println("Display");
	}
	@Test
	public void a4b4()
	{
		System.out.println("Exit");
	}
	@Test
	public void a5b5()
	{
		System.out.println("Print");
	}
}
