package Selenium;
import org.junit.*;
import static org.junit.Assert.*;
public class TestAssertion {
@Test	
	public void assertion()
	{
		String str1=new String("abc");
		String str2=new String("abc");
		String str3=null;
		String str4="abc";
		String str5="abc";
		int val1=6;
		int val2=5;
		String[] expectedarray={"one","two","three"};
		String[] resultarray={"one","two","three"};
		
		//Check two objects are equal
		assertEquals(str1,str2);
		//Check the condition is true
		assertTrue(val1>val2);
		//assertTrue(val1<val2);
		//Check that condition is false
		assertFalse(val2>val1);
		//Check that the object is not null
		assertNotNull(str1);
		//Check that the object is null
		assertNull(str3);
		//Check if two object references point to same object
		assertSame(str4,str5);
		//Check if two object references not point to same object
		assertNotSame(str1,str3);
		//Check whether two arrays are equal to each other
		assertArrayEquals(expectedarray,resultarray);
	}
}
