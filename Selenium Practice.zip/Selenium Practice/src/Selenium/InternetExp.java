package Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.*;


public class InternetExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.ie.driver","D:\\IEDriverServer_x64_2.53.1\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver();
		String baseurl=("http://www.google.com/");
		driver.get(baseurl);
	}
}