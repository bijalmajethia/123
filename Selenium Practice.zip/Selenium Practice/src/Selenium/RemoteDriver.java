package Selenium;
import java.net.URL;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.MalformedURLException;

public class RemoteDriver {
		WebDriver driver;
		String baseurl,nodeurl;
		@BeforeTest
		public void display() throws MalformedURLException
		{
			//baseurl="http://demo.opencart.com/";
			//baseurl="http:/www.opencart.com/";
			baseurl="file:///D:/BIJAL/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html";
			nodeurl="http://10.102.52.75:5666/wd/hub";
			DesiredCapabilities t=new DesiredCapabilities().chrome();
			t.setBrowserName("chrome");
			t.setPlatform(Platform.WINDOWS);
			driver=new RemoteWebDriver(new URL(nodeurl),t);
		}
		@AfterTest
		public void aftertest()
		{
			//driver.close;
		}
		@Test
		public void simpletest()
		{
			driver.get(baseurl);
			//Thread.sleep(1000);
			//Assert.assertEquals("Your Store",driver.getTitle());
			AssertJUnit.assertEquals("Email Registration Form",driver.getTitle());
		}
}
