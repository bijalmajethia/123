package Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

public class HeadlessBrowser {
	public static void main(String []args){
		System.setProperty("phantomjs.binary.path","D:\\phantomjs.exe");
		//File file = new File("C:\\Program Files\\PhantomJS\\phantomjs.exe);
		//System.setProperty("phantomjs.binary.path",file.getAbsolutePath();
		WebDriver driver = new PhantomJSDriver();
		driver.get("https://demo.opencart.com/");
		System.out.println("Page title is:"+driver.getTitle());
		driver.close();
	}
}