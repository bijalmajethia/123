package Selenium;

import org.junit.*;


public class JunitDemo1 {
@BeforeClass
	
	public static void bclass()
	{
		System.out.println("After Class");
	}

@Before	
	public void before()
	{
		System.out.println("Before");
	}
@Test
	public void mytest1()
	{
		System.out.println("Test 1");
	}
@Ignore
@Test
	public void mytest2()
	{
		System.out.println("Test 2");
	}
@After
	public void after()
	{
		System.out.println("After");
	}
@AfterClass
	public static void aclass()
	{
		System.out.println("After Class");
	}
}