package demo;

import java.net.MalformedURLException;
import java.net.URL;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

 public class HubNode {
    
	
	WebDriver driver;
	String baseurl,nodeurl;
	
	
	@BeforeTest
	public void display() throws MalformedURLException 
	{
	  baseurl="file:///D:/Vishal/Module2_3_4 Material FOR EXAM/Module 4/Selenium/Selenium Installations/Selenium Demos & Lab files/Lesson 5-HTML Pages/Lesson 5-HTML Pages/WorkingWithForms.html";
	    nodeurl="http://10.102.52.8:5666/wd/hub";
	    
	    
	    
	    DesiredCapabilities t=new DesiredCapabilities().chrome();
	    
	    
	    t.setBrowserName("chrome");
	    t.setPlatform(Platform.WINDOWS);
	    driver=new RemoteWebDriver(new URL(nodeurl),t);
	    
	}

	
	@AfterTest
	public void aftertest()
	{
		// driver.close
	}
	@Test
	public void simpletest()
	{
		driver.get(baseurl);
		//Thread.sleep(1000);
		//Assert.assertEquals(" Your Store",driver.getTitle());
		Assert.assertEquals("Email Registration Forms",driver.getTitle());
	}
}
